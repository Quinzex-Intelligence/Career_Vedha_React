import React, { useMemo } from 'react';
import { useLocation, Link, useNavigate } from 'react-router-dom';
import './TaxonomyTabs.css';

const TaxonomyTabs = ({ sectionSlug }) => {
    const location = useLocation();
    const navigate = useNavigate();
    const query = new URLSearchParams(location.search);
    
    // Some sections use ?level=, academics uses ?category=
    const categorySlug = query.get('category') || query.get('level');
    const subSlug = query.get('sub');
    const segmentSlug = query.get('segment');

    const tabsInfo = useMemo(() => {
        if (!categorySlug || !subSlug) return { tabs: [], parent: null };
        try {
            const cached = localStorage.getItem('cv_nav_tree_v2');
            if (!cached) return { tabs: [], parent: null };
            
            const { data } = JSON.parse(cached);
            
            // Map the prop sectionSlug (e.g. 'campus-pages') to the key in the cache (e.g. 'campusPages')
            const mapSlugToKey = (slug) => {
                if (slug === 'campus-pages') return 'campusPages';
                if (slug === 'current-affairs') return 'currentAffairs';
                if (slug === 'academic-exams' || slug === 'exams') return 'exams';
                return slug;
            };

            const sectionData = data[mapSlugToKey(sectionSlug)];
            if (!sectionData) return { tabs: [], parent: null };

            // Find the category node (Depth-0)
            const categoryNode = sectionData.find(c => 
                c.slug === categorySlug || 
                c.id === parseInt(categorySlug) ||
                c.id === categorySlug
            );
            if (!categoryNode || !categoryNode.children) return { tabs: [], parent: null };

            // Find the subcategory node (Depth-1)
            const subNode = categoryNode.children.find(s => 
                s.slug === subSlug || 
                s.id === parseInt(subSlug) ||
                s.id === subSlug
            );
            if (!subNode) return { tabs: [], parent: null };

            return { tabs: subNode.children || [], parent: subNode };

        } catch (error) {
            console.error("Failed to parse taxonomy cache for tabs:", error);
            return { tabs: [], parent: null };
        }
    }, [sectionSlug, categorySlug, subSlug]);

    const { tabs, parent } = tabsInfo;

    // Build the URL to switch tabs precisely
    const buildTabUrl = (tabSlug) => {
        const params = new URLSearchParams(location.search);
        params.set('segment', tabSlug);
        return `${location.pathname}?${params.toString()}`;
    };

    if (!tabs || tabs.length === 0) {
        return null;
    }

    // Auto-select the first tab if none is selected in the URL
    if (!segmentSlug && tabs.length > 0) {
        // We use setTimeout to avoid React state update warnings during render
        setTimeout(() => {
            navigate(buildTabUrl(tabs[0].slug), { replace: true });
        }, 0);
    }

    return (
        <div className="taxonomy-tabs-wrapper">
            <div className="taxonomy-tabs-container">
                <div className="taxonomy-tabs-scroll">
                    {tabs.map(tab => {
                        // Mark active if it matches the segment in URL, or if it's the very first item and no segment is in URL
                        const isActive = segmentSlug === tab.slug || (!segmentSlug && tabs[0].id === tab.id);
                        return (
                            <Link 
                                key={tab.id}
                                to={buildTabUrl(tab.slug)}
                                className={`taxonomy-tab ${isActive ? 'active' : ''}`}
                            >
                                {tab.name}
                            </Link>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};

export default TaxonomyTabs;
